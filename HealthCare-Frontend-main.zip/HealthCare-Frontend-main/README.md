# HealthCare Initiative

Login Credentials:

Admin username = aicheckup 

Admin password = pwd@aicheckup

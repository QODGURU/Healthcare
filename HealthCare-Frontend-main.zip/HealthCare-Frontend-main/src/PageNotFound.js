
import React from 'react';

const PageNotFound = () => {
  return (
    <div style={{textAlign:'center',padding:"100px 0 100px"}}>Page not found</div>
  );
};

export default PageNotFound;
